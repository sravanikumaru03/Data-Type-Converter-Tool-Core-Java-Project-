import java.util.Scanner;

public class DataTypeConverter {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n=== DATA TYPE CONVERTER TOOL ===");
            System.out.println("1. int to String");
            System.out.println("2. String to int");
            System.out.println("3. char to String");
            System.out.println("4. String to char");
            System.out.println("5. int to char");
            System.out.println("6. char to int");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");

            while (!scanner.hasNextInt()) {
                System.out.print("Invalid input. Enter a number: ");
                scanner.next(); // discard invalid input
            }

            choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    // Will implement in next step
                    break;
                case 2:
                    // Will implement in next step
                    break;
                case 3:
                    // Will implement in next step
                    break;
                case 4:
                    // Will implement in next step
                    break;
                case 5:
                    // Will implement in next step
                    break;
                case 6:
                    // Will implement in next step
                    break;
                case 0:
                    System.out.println("Exiting the converter. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }

        } while (choice != 0);

        scanner.close();
    }
}
	}
