package com.DataTypeTool;

import java.util.Scanner;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class DataTypeConverter {

    // ANSI color codes
    static final String RESET = "\u001B[0m";
    static final String GREEN = "\u001B[32m";
    static final String RED = "\u001B[31m";
    static final String CYAN = "\u001B[36m";
    static final String YELLOW = "\u001B[33m";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        printWelcomeBanner();

        do {
            printMenu();
            choice = getValidChoice(scanner);

            switch (choice) {
                case 1 -> intToString(scanner);
                case 2 -> stringToInt(scanner);
                case 3 -> charToString(scanner);
                case 4 -> stringToChar(scanner);
                case 5 -> intToChar(scanner);
                case 6 -> charToInt(scanner);
                case 0 -> System.out.println(GREEN + "✅ Exiting... Thank you for using the converter!" + RESET);
                default -> System.out.println(RED + "❌ Invalid choice. Try again." + RESET);
            }

        } while (choice != 0);
    }

    private static void printWelcomeBanner() {
        String time = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy | hh:mm a"));

        System.out.println(CYAN);
        System.out.println("╔════════════════════════════════════════════════════════════╗");
        System.out.println("║                                                            ║");
        System.out.println("║            👋 WELCOME TO DATA TYPE CONVERTER TOOL          ║");
        System.out.println("║                                                            ║");
        System.out.println("║     🔄 Easily convert between int, String, and char types  ║");
        System.out.println("║                                                            ║");
        System.out.printf ("║     🕒 Session Started: %-34s ║\n", time);
        System.out.println("║                                                            ║");
        System.out.println("╚════════════════════════════════════════════════════════════╝");
        System.out.print(RESET);
    }




    private static void printMenu() {
        System.out.println(YELLOW + "\n+----------------------------------------+");
        System.out.println("|       🚀 DATA TYPE CONVERSION MENU      |");
        System.out.println("+----------------------------------------+");
        System.out.println("| 1. int       ➝ String                   |");
        System.out.println("| 2. String    ➝ int                      |");
        System.out.println("| 3. char      ➝ String                   |");
        System.out.println("| 4. String    ➝ char                     |");
        System.out.println("| 5. int       ➝ char                     |");
        System.out.println("| 6. char      ➝ int                      |");
        System.out.println("| 0. ❌ Exit                              |");
        System.out.println("+----------------------------------------+" + RESET);
        System.out.print("Enter your choice: ");
    }

    private static int getValidChoice(Scanner scanner) {
        while (!scanner.hasNextInt()) {
            System.out.print(RED + "Enter a number: " + RESET);
            scanner.next();
        }
        int choice = scanner.nextInt();
        scanner.nextLine(); // consume newline
        return choice;
    }

    private static void intToString(Scanner scanner) {
        System.out.print("Enter an integer: ");
        while (!scanner.hasNextInt()) {
            System.out.print(RED + "Invalid input. Enter a valid integer: " + RESET);
            scanner.next();
        }
        int number = scanner.nextInt();
        scanner.nextLine();
        String result = Integer.toString(number);
        printBoxedOutput("int ➝ String", "\"" + result + "\"");
    }

    private static void stringToInt(Scanner scanner) {
        System.out.print("Enter a numeric string: ");
        String input = scanner.nextLine();
        try {
            int result = Integer.parseInt(input);
            printBoxedOutput("String ➝ int", String.valueOf(result));
        } catch (NumberFormatException e) {
            System.out.println(RED + "❌ Cannot convert to int. Input must be numeric." + RESET);
        }
    }

    private static void charToString(Scanner scanner) {
        System.out.print("Enter a single character: ");
        String input = scanner.nextLine();
        if (input.length() != 1) {
            System.out.println(RED + "❌ Invalid input. Enter exactly one character." + RESET);
        } else {
            String result = Character.toString(input.charAt(0));
            printBoxedOutput("char ➝ String", "\"" + result + "\"");
        }
    }

    private static void stringToChar(Scanner scanner) {
        System.out.print("Enter a string: ");
        String input = scanner.nextLine();
        if (input.isEmpty()) {
            System.out.println(RED + "❌ Cannot convert empty string to char." + RESET);
        } else {
            char result = input.charAt(0);
            printBoxedOutput("String ➝ char", "'" + result + "'");
        }
    }

    private static void intToChar(Scanner scanner) {
        System.out.print("Enter an integer (0–65535): ");
        while (!scanner.hasNextInt()) {
            System.out.print(RED + "Invalid input. Enter a valid integer: " + RESET);
            scanner.next();
        }
        int value = scanner.nextInt();
        scanner.nextLine();
        if (value < 0 || value > 65535) {
            System.out.println(RED + "❌ Out of range. Must be between 0–65535." + RESET);
        } else {
            char result = (char) value;
            printBoxedOutput("int ➝ char", "'" + result + "'");
        }
    }

    private static void charToInt(Scanner scanner) {
        System.out.print("Enter a character: ");
        String input = scanner.nextLine();
        if (input.length() != 1) {
            System.out.println(RED + "❌ Please enter a single character." + RESET);
        } else {
            int result = (int) input.charAt(0);
            printBoxedOutput("char ➝ int (ASCII)", String.valueOf(result));
        }
    }

    private static void printBoxedOutput(String title, String result) {
        System.out.println(CYAN + "+--------------------------------------+");
        System.out.printf("| %-36s |\n", title + " Result:");
        System.out.println("+--------------------------------------+");
        System.out.printf("| %-36s |\n", result);
        System.out.println("+--------------------------------------+" + RESET);
    }
}
